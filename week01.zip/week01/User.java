package museruka;

public class User {

    private String password;
    private String salt;
    private String hash;

   
   
    public User(String password) {
        this.password = password;
    }

    public String getPassword() {
        return this.password;
    }

   
    public void setPassword(String p) {
        this.password = p;
    }


    public String getSalt() {
        return this.salt;
    }

 
 
    public void setSalt(String s) {
        this.salt = s;
    }


    public String getHashedPassword() {
        return this.hash;
    }


    public void setHashedPassword(String h) {
        this.hash = h;
    }
}
